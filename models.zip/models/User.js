import mongoose from 'mongoose'
import bcrypt from 'bcryptjs'

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    // Mirrored onto Shop/ServiceProvider too (see those models) so the
    // public-profile lookup can query those collections directly by
    // username without an extra join back to User.
    username: { type: String, unique: true, sparse: true, trim: true },
    password: { type: String, required: true, minlength: 6, select: false },
    // 'consumer' is the default. A user becomes 'seller' the moment they
    // finish the "Start Yours" flow and create a Shop or ServiceProvider.
    role: { type: String, enum: ['consumer', 'seller'], default: 'consumer' },
    // Only meaningful when role === 'seller'.
    sellerType: { type: String, enum: ['shop', 'service', null], default: null },
    // Real device location (browser Geolocation API), saved whenever the
    // app opens with a logged-in session and refreshed on every seller
    // login. Used as the "you are here" reference point for nearby
    // shop/service sorting when the person hasn't searched a specific area.
    location: {
      lat: { type: Number, default: null },
      lng: { type: Number, default: null },
      updatedAt: { type: Date, default: null },
    },
  },
  { timestamps: true }
)

userSchema.pre('save', async function hashPassword(next) {
  if (!this.isModified('password')) return next()
  const salt = await bcrypt.genSalt(10)
  this.password = await bcrypt.hash(this.password, salt)
  next()
})

userSchema.methods.comparePassword = function comparePassword(candidate) {
  return bcrypt.compare(candidate, this.password)
}

userSchema.methods.toSafeObject = function toSafeObject() {
  return {
    id: this._id,
    name: this.name,
    email: this.email,
    username: this.username,
    role: this.role,
    sellerType: this.sellerType,
    location: this.location,
  }
}

export default mongoose.model('User', userSchema)
